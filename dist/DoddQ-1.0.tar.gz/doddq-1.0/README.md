DoddQ
=====


Summary
-------

A simple library for use with Qiskit.


Permissions
-----------

In practice, the license on any code I write means very little, but for those who want a some semblance of formality, let it be stated that all code is available under the [MIT License](https://github.com/tomdodd4598/doddq/blob/main/LICENSE.md).
